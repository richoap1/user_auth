package com.example.user_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
