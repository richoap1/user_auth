import 'package:flutter/material.dart';
import 'userlist_screen.dart'; // Pastikan untuk mengimpor UserListScreen
import 'login_screen.dart'; // Import halaman login

class ProfileScreen extends StatelessWidget {
  final String username; // Menyimpan username yang diterima
  final String alamat; // Menyimpan alamat yang diterima
  final int umur; // Menyimpan umur yang diterima

  // Constructor untuk menerima username, alamat, dan umur
  const ProfileScreen({
    super.key,
    required this.username,
    required this.alamat, // Tambahkan parameter alamat
    required this.umur, // Tambahkan parameter umur
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Welcome, $username!',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Text(
              'Alamat: ${alamat.isNotEmpty ? alamat : "Alamat tidak tersedia"}', // Tampilkan alamat atau pesan default
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 10),
            Text(
              'Umur: ${umur > 0 ? umur.toString() : "Umur tidak tersedia"}', // Tampilkan umur atau pesan default
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigasi ke UserListScreen
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserListScreen()),
                );
              },
              child: Text('View User List'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigasi kembali ke halaman login
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          LoginScreen()), // Ganti dengan LoginScreen
                );
              },
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}
