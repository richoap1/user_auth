import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'login_screen.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _alamatController =
      TextEditingController(); // Tambahkan controller untuk alamat
  final _umurController =
      TextEditingController(); // Tambahkan controller untuk umur
  String _message = '';

  Future<void> _register() async {
    final response = await http.post(
      Uri.parse('http://localhost/api.php?action=register'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, dynamic>{
        // Ubah tipe data menjadi dynamic
        'action': 'register',
        'username': _usernameController.text,
        'password': _passwordController.text,
        'alamat': _alamatController.text, // Tambahkan alamat
        'umur': int.parse(_umurController.text), // Tambahkan umur
      }),
    );

    setState(() {
      _message = json.decode(response.body)['message'];
    });

    if (_message == "User registered successfully") {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            TextField(
              controller: _alamatController, // Tambahkan TextField untuk alamat
              decoration: InputDecoration(labelText: 'Alamat'),
            ),
            TextField(
              controller: _umurController, // Tambahkan TextField untuk umur
              decoration: InputDecoration(labelText: 'Umur'),
              keyboardType: TextInputType.number, // Set keyboard untuk angka
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _register,
              child: Text('Register'),
            ),
            SizedBox(height: 20),
            Text(_message),
          ],
        ),
      ),
    );
  }
}
