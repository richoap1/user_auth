import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'profile_screen.dart'; // Import ProfileScreen

class UserListScreen extends StatefulWidget {
  const UserListScreen({super.key});

  @override
  _UserListScreenState createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  List<dynamic> _users = [];
  String _message = '';

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    try {
      final response = await http.get(
        Uri.parse(
            'http://localhost/api.php?action=get_users'), // Ganti dengan URL yang sesuai
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        // Pastikan 'users' ada dan bukan null
        if (data['users'] != null && data['users'] is List) {
          setState(() {
            _users = data['users'];
          });
        } else {
          setState(() {
            _message = 'No users found';
          });
        }
      } else {
        setState(() {
          _message = 'Failed to load users: ${response.reasonPhrase}';
        });
      }
    } catch (e) {
      setState(() {
        _message = 'Error: $e';
      });
    }
  }

  void _navigateToProfile(String username) async {
    try {
      final response = await http.get(
        Uri.parse(
            'http://localhost/api.php?action=get_user_details&username=$username'), // Ganti dengan URL yang sesuai
      );

      if (response.statusCode == 200) {
        final userDetails = json.decode(response.body);
        if (userDetails['message'] == null) {
          // Navigasi ke halaman profil dengan data pengguna
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProfileScreen(
                username: userDetails['username'],
                alamat: userDetails['alamat'] ?? "Alamat tidak tersedia",
                umur: userDetails['umur'] ?? 0,
              ),
            ),
          );
        } else {
          // Tampilkan pesan jika pengguna tidak ditemukan
          setState(() {
            _message = userDetails['message'];
          });
        }
      } else {
        setState(() {
          _message = 'Failed to load user details: ${response.reasonPhrase}';
        });
      }
    } catch (e) {
      setState(() {
        _message = 'Error: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User List'),
      ),
      body: _message.isNotEmpty
          ? Center(child: Text(_message))
          : ListView.builder(
              itemCount: _users.length,
              itemBuilder: (context, index) {
                final user = _users[index];
                return ListTile(
                  title: Text(user['username']), // Menampilkan username
                  onTap: () => _navigateToProfile(
                      user['username']), // Navigasi saat diklik
                );
              },
            ),
    );
  }
}
