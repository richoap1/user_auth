import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'profile_screen.dart'; // Import halaman profil
import 'registration_screen.dart'; // Import halaman registrasi

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _message = '';

  Future<void> _login() async {
    // Validasi input
    if (_usernameController.text.isEmpty || _passwordController.text.isEmpty) {
      setState(() {
        _message = 'Username and password cannot be empty';
      });
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(
            'http://localhost/api.php?action=login'), // Ganti dengan URL yang sesuai
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'action': 'login',
          'username': _usernameController.text,
          'password': _passwordController.text,
        }),
      );

      // Cek status respons
      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        setState(() {
          _message = responseData['message'] ??
              'Unknown error'; // Tangani kemungkinan null
        });

        if (_message == "Login successful") {
          // Ambil alamat dan umur dari respons
          String alamat = responseData['alamat'] ??
              "Alamat tidak tersedia"; // Gunakan default jika null
          int umur = responseData['umur'] ?? 0; // Gunakan default jika null

          // Navigasi ke halaman profil dengan username, alamat, dan umur
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ProfileScreen(
                username: _usernameController.text,
                alamat: alamat,
                umur: umur,
              ),
            ),
          );
        }
      } else {
        setState(() {
          _message = 'Login failed: ${response.reasonPhrase}';
        });
      }
    } catch (e) {
      setState(() {
        _message = 'Error: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('Login'),
            ),
            SizedBox(height: 20),
            Text(_message, style: TextStyle(color: Colors.red)),
            SizedBox(height: 20),
            TextButton(
              onPressed: () {
                // Navigasi ke halaman registrasi
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RegistrationScreen()),
                );
              },
              child: Text('Don\'t have an account? Register here'),
            ),
          ],
        ),
      ),
    );
  }
}
